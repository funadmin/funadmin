<?php
return [
    'The activation email has been sent successfully, please enter the email verification code, the activation email'=>'验证码已经发到您的邮箱，请输入验证码激活账号',
    'inconsistent passwords'=>'密码不一致',
    'edit failed'=>'编辑失败',
    'edit successfully'=>'编辑成功',
    'Repeat password error'=>'重复密码不正确',
    'Old password error'=>'旧密码不正确',
    'reg successful'=>'注册成功'
];
?>
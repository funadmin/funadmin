<?php

declare (strict_types = 1);

namespace think\model\contract;

interface EnumTransform
{
    public function value();
}

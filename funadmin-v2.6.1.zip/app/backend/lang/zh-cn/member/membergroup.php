<?php
return [
        'Member'                                    =>"会员 ",
        'GroupName'                                 =>"分组名",
        'GroupAdd'                                  =>"分组名添加",
        'GroupEdit'                                 =>"分组名编辑",
        'GroupDel'                                  =>"分组名删除",
        'GroupModify'                               =>"分组名修改",
        'Status'                                    => '状态',
        'Rules'                                    => '规则',


];
drop table if exists `__PREFIX__bbs`;

drop table if exists `__PREFIX__bbs_cate`;

drop table if exists `__PREFIX__bbs_collect`;

drop table if exists `__PREFIX__bbs_comment`;

drop table if exists `__PREFIX__bbs_comment_like`;

drop table if exists `__PREFIX__bbs_message`;

drop table if exists `__PREFIX__bbs_user_sign`;

drop table if exists `__PREFIX__bbs_user_sign_rule`;

drop table if exists `__PREFIX__bbs_link`;

drop table if exists `__PREFIX__bbs_adv`;

drop table if exists `__PREFIX__bbs_adv_position`;

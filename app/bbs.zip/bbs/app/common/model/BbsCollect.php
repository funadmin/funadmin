<?php


namespace app\common\model;


class BbsCollect extends Common {

    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }


}

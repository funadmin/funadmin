/**
 * FunAdmin
 * ============================================================================
 * 版权所有 2017-2028 FunAdmin，并保留所有权利。
 * 网站地址: http://www.FunAdmin.com
 * ----------------------------------------------------------------------------
 * 采用最新Thinkphp6实现
 * ============================================================================
 * Author: yuege
 * Date: 2021/12/11
 * Time: 15:48
 */

define(['jquery','table','form'], function (undefined,Table,Form) {
    let Controller = {
        index: function () {
            Controller.api.bindevent();
            layui.form.val("form", Config.formData);
            layui.form.render();
        },
        api: {
            bindevent: function () {
                Form.api.bindEvent($('form'), function (res) {
                    Fun.toastr.success(res.msg, setTimeout(function () {
                    }, 0));
                    html = '请求成功:\n';
                    html+=res.data.data
                    $("textarea[name=result]").val(html);
                    return false;
                }, function (res) {
                    $("textarea[name=result]").val(res.data);
                    Fun.toastr.error(res.msg);
                    return false;
                })
            }
        }

    };
    return Controller;
});
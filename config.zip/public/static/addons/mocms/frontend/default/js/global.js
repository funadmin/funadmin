/**

 @Name: funadimin - 企业模板
 @Author: funadimin
 @Copyright: www.funadmin.com

 */

layui.define(['jquery', 'element', 'carousel','form'], function (exports) {
    var $ = layui.jquery
        , element = layui.element
        , carousel = layui.carousel,
    form = layui.form;

    //轮播渲染
    carousel.render({
        elem: '#banner'
        , width: '100%'
        , height: '600px'
        , arrow: 'always'
    });
//轮播渲染
    carousel.render({
        elem: '#topic'
        , width: '100%'
        , height: '400px'
        , arrow: 'always'
    });
    //滚动监听
    $(window).scroll(function () {
        var scr = $(document).scrollTop();
        scr > 0 ? $(".nav").addClass('scroll') : $(".nav").removeClass('scroll');
    });

    //轮播文字
    $(function () {
        $('.banner').children('.title').addClass('active');
    })

    //关于内容
    $('.main-about').find('.aboutab').children('li').each(function (index) {
        $(this).on('click', function () {
            $(this).addClass('layui-this').siblings().removeClass('layui-this');
            $('.aboutab').siblings().fadeOut("fast");
            $('.aboutab').siblings().eq(index).fadeIn("");
        });
    });

    $('.layui-fixbar .layui-fixbar-top').click(function () {
        $('html,body').animate({scrollTop: '0px'}, 800);
    })
    //新闻字段截取
    $(function () {
        $(".main-news").find(".content").each(function () {
            var span = $(this).find(".detail").children("span")
                , spanTxt = span.html();
            if (document.body.clientWidth > 463) {
                span.html(spanTxt);
            } else {
                span.html(span.html().substring(0, 42) + '...')
            }
            ;
            $(window).resize(function () {
                if (document.body.clientWidth > 463) {
                    span.html(spanTxt);
                } else {
                    span.html(span.html().substring(0, 42) + '...')
                }
                ;
            });
        });
    });

    $('#download').click(function () {
        var url = $(this).data('url')
        var id = $(this).data('id')
        $.post(url, {id: id},
            function (res) {
                if (res.code <= 0) {
                    layui.layer.msg(res.msg);
                } else {
                    layui.layer.msg(res.msg);
                    window.location.href = res.data.url;
                }
            })
    });


    //监听提交
    form.on('submit(submit)', function (data) {
        var url = $(this).data('url');
        $.ajax({
            url:url,
            type:'post',
            data:data.field,
            dataType: 'json',
            success:function(res){
                if(res.code>=1){
                    layer.msg(data.msg,{icon: 1});
                    $("form")[0].reset();
                    layui.form.render();
                }
                else{
                    layer.msg(res.msg,{icon: 2,time:2500},function (){
                        if(res.url) window.location.href = res.url;
                    });
                    return false;
                }
            },
            error:function(res){
                layer.msg(res.msg,{icon: 2});
                return false;
            },
        });
        return false;
    });
    exports('global', {});
});
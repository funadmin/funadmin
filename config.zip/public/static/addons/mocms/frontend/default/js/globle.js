/**

 @Name: funadimin - 企业模板
 @Author: funadimin
 @Copyright: www.funadmin.com

 */

layui.define(['jquery', 'element', 'carousel'], function(exports){
  var $ = layui.jquery
  ,element = layui.element
  ,carousel = layui.carousel;

  //轮播渲染
  carousel.render({
    elem: '#banner'
    ,width: '100%'
    ,height: '600px'
    ,arrow: 'always'
  });

  //滚动监听
  $(window).scroll(function() {
    var scr=$(document).scrollTop();
    scr > 0 ? $(".nav").addClass('scroll') : $(".nav").removeClass('scroll');
  });

  //轮播文字
  $(function(){
    $('.banner').children('.title').addClass('active');
  })

  //关于内容
  $('.main-about').find('.aboutab').children('li').each(function(index){
    $(this).on('click', function(){
      $(this).addClass('layui-this').siblings().removeClass('layui-this');
      $('.aboutab').siblings().fadeOut("fast");
      $('.aboutab').siblings().eq(index).fadeIn("");
    });
  });


  //新闻字段截取
  $(function(){
    $(".main-news").find(".content").each(function(){
      var span = $(this).find(".detail").children("span")
      ,spanTxt = span.html();
      if(document.body.clientWidth > 463){
        span.html(spanTxt);
      }else{
        span.html(span.html().substring(0, 42)+ '...')
      };
      $(window).resize(function(){   
        if(document.body.clientWidth > 463){
          span.html(spanTxt);
        }else{
          span.html(span.html().substring(0, 42)+ '...')
        };
      });
    });
  });  

  exports('global', {});
});
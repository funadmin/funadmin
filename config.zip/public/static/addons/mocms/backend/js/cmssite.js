define(['table','form'], function (Table,Form) {
    let Controller = {
        index: function () {
            Table.init = {
                table_elem: 'list',
                tableId: 'list',
                requests:{
                    index_url:'addons/mocms/backend/cmsSite/index',
                    add_url:'addons/mocms/backend/cmsSite/add',
                    edit_url:'addons/mocms/backend/cmsSite/edit',
                    destroy_url:'addons/mocms/backend/cmsSite/destroy',
                    delete_url:'addons/mocms/backend/cmsSite/delete',
                    recycle_url:'addons/mocms/backend/cmsSite/recycle',
                    import_url:'addons/mocms/backend/cmsSite/import',
                    export_url:'addons/mocms/backend/cmsSite/export',
                    modify_url:'addons/mocms/backend/cmsSite/modify',

                }
            }
            Table.render({
                elem: '#' + Table.init.table_elem,
                id: Table.init.tableId,
                url: Fun.url(Table.init.requests.index_url),
                init: Table.init,
                toolbar: ['refresh','add','destroy','export','recycle'],
                cols: [[
                    {checkbox: true,},
                    {field: 'id', title: __('ID'), sort:true,},
                    {field:'language_id',search: true,title: __('LanguageId'),selectList:languageIdList,sort:true,templet: Table.templet.tags},
                    {field:'name', title: __('Name'),align: 'center',sort:true},
                    {field:'siteflag', title: __('Siteflag'),align: 'center',sort:true},
                    // {field:'domain', title: __('Domain'),align: 'center',sort:true},
                    {field:'url', title: __('Url'),align: 'center',sort:true,templet:Table.templet.url},
                    {field:'logo', title: __('Logo'),align: 'center',sort:true,templet:Table.templet.image},
                    {field:'favicon', title: __('Favicon'),align: 'center',sort:true,templet:Table.templet.image},
                    {field:'theme', title: __('Theme'),align: 'center',sort:true},
                    {field:'sort',title: __('Sort'),align: 'center',edit:'text',sort:true},
                    {field:'is_absolute',search: 'select',title: __('IsAbsolute'),filter: 'is_absolute',selectList:isAbsoluteList,sort:true,templet: Table.templet.select},
                    {field:'translate',search: 'select',title: __('Translate'),filter: 'translate',selectList:translateList,sort:true,templet: Table.templet.select},
                    {field:'is_default',search: 'select',title: __('IsDefault'),filter: 'is_default',selectList:isDefaultList,sort:true,templet: Table.templet.select},
                    {field:'status',search: 'select',title: __('Status'),filter: 'status',selectList:statusList,sort:true,templet: Table.templet.select},
                    {field:'create_time',title: __('CreateTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    // {field:'delete_time',title: __('DeleteTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    {
                        minWidth: 250,
                        align: "center",
                        title: __("Operat"),
                        init: Table.init,
                        templet: Table.templet.operat,
                        operat: ["edit", "destroy","delete"]
                    },
                ]],
                limits: [10, 15, 20, 25, 50, 100,500],
                limit: 15,
                page: true,
                done: function (res, curr, count) {
                }
            });

            let table = $('#'+Table.init.table_elem);
            Table.api.bindEvent(table);
        },
        add: function () {
            Controller.api.bindevent()
        },
        edit: function () {
            Controller.api.bindevent()
        },
        recycle: function () {
            Table.init = {
                table_elem: 'list',
                tableId: 'list',
                requests: {
                    delete_url:'addons/mocms/backend/cmsSite/delete',
                    recycle_url:'addons/mocms/backend/cmsSite/recycle',
                    restore_url:'addons/mocms/backend/cmsSite/restore',

                },
            };
            Table.render({
                elem: '#' + Table.init.table_elem,
                id: Table.init.tableId,
                url: Fun.url(Table.init.requests.recycle_url),
                init: Table.init,
                toolbar: ['refresh','delete','restore'],
                cols: [[
                    {checkbox: true,},
                    {field: 'id', title: __('ID'), sort:true,},
                    {field:'language_id',search: true,title: __('LanguageId'),selectList:languageIdList,sort:true,templet: Table.templet.tags},
                    {field:'name', title: __('Name'),align: 'center',sort:true},
                    {field:'siteflag', title: __('Siteflag'),align: 'center',sort:true},
                    // {field:'domain', title: __('Domain'),align: 'center',sort:true},
                    {field:'url', title: __('Url'),align: 'center',sort:true},
                    {field:'logo', title: __('Logo'),align: 'center',sort:true},
                    {field:'favicon', title: __('Favicon'),align: 'center',sort:true},
                    {field:'theme', title: __('Theme'),align: 'center',sort:true},
                    // {field:'title', title: __('Title'),align: 'center',sort:true},
                    // {field:'seotitle', title: __('Seotitle'),align: 'center',sort:true},
                    // {field:'keywords', title: __('Keywords'),align: 'center',sort:true},
                    // {field:'description', title: __('Description'),align: 'center',sort:true},
                    // {field:'child',search: 'select',title: __('Child'),filter: 'child',selectList:childList,sort:true,templet: Table.templet.select},
                    // {field:'pid',title: __('Pid'),align: 'center',sort:true},
                    // {field:'arrparentid', title: __('Arrparentid'),align: 'center',sort:true},
                    // {field:'arrchildid', title: __('Arrchildid'),align: 'center',sort:true},
                    {field:'sort',title: __('Sort'),align: 'center',edit:'text',sort:true},
                    // {field:'is_absolute',search: 'select',title: __('IsAbsolute'),filter: 'is_absolute',selectList:isAbsoluteList,sort:true,templet: Table.templet.select},
                    // {field:'translate',search: 'select',title: __('Translate'),filter: 'translate',selectList:translateList,sort:true,templet: Table.templet.select},
                    {field:'is_default',search: 'select',title: __('IsDefault'),filter: 'is_default',selectList:isDefaultList,sort:true,templet: Table.templet.select},
                    {field:'status',search: 'select',title: __('Status'),filter: 'status',selectList:statusList,sort:true,templet: Table.templet.select},
                    {field:'create_time',title: __('CreateTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    // {field:'delete_time',title: __('DeleteTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    {
                        minWidth: 250,
                        align: "center",
                        title: __("Operat"),
                        init: Table.init,
                        templet: Table.templet.operat,
                        operat: ["restore","delete"]
                    },
                ]],
                limits: [10, 15, 20, 25, 50, 100,500],
                limit: 15,
                page: true,
                done: function (res, curr, count) {
                }
            });
            let table = $('#'+Table.init.table_elem);
            Table.api.bindEvent(table);
        },
        api: {
            bindevent: function () {
                Form.api.bindEvent($('form'))
            }
        }
    };
    return Controller;
});
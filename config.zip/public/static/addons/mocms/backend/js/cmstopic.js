define(['table','form'], function (Table,Form) {
    let Controller = {
        index: function () {
            Table.init = {
                table_elem: 'list',
                tableId: 'list',
                requests:{
                    index_url:'addons/mocms/backend/cmsTopic/index',
                    add_url:'addons/mocms/backend/cmsTopic/add',
                    edit_url:'addons/mocms/backend/cmsTopic/edit',
                    destroy_url:'addons/mocms/backend/cmsTopic/destroy',
                    delete_url:'addons/mocms/backend/cmsTopic/delete',
                    recycle_url:'addons/mocms/backend/cmsTopic/recycle',
                    import_url:'addons/mocms/backend/cmsTopic/import',
                    export_url:'addons/mocms/backend/cmsTopic/export',
                    modify_url:'addons/mocms/backend/cmsTopic/modify',

                }
            }
            Table.render({
                elem: '#' + Table.init.table_elem,
                id: Table.init.tableId,
                url: Fun.url(Table.init.requests.index_url),
                init: Table.init,
                toolbar: ['refresh','add','destroy','export','recycle'],
                cols: [[
                    {checkbox: true,},
                    {field: 'id', title: __('ID'), sort:true,},
                    // {field:'site_ids', title: __('SiteIds'),align: 'center',sort:true},
                    // {field:'pid', title: __('Pid'),align: 'center',sort:true},
                    // {field:'member_id', title: __('MemberId'),align: 'center',sort:true},
                    {field:'title', title: __('Title'),align: 'center',sort:true},
                    {field:'author', title: __('Author'),align: 'center',sort:true},
                    // {field:'titlestyle', title: __('Titlestyle'),align: 'center',sort:true},
                    // {field:'admin_id',search: true,title: __('AdminId'),selectList:adminIdList,sort:true,templet: Table.templet.tags},
                    // {field:'seotitle', title: __('Seotitle'),align: 'center',sort:true},
                    // {field:'thumb',title: __('Thumb'),sort:true,templet: Table.templet.image},
                    // {field:'keywords', title: __('Keywords'),align: 'center',sort:true},
                    // {field:'description', title: __('description'),align: 'center',sort:true},
                    // {field:'remark', title: __('Remark'),align: 'center',sort:true},
                    {field:'diyname', title: __('Diyname'),align: 'center',sort:true},
                    // {field:'tags', title: __('Tags'),align: 'center',sort:true},
                    {field:'status',search: 'select',title: __('Status'),filter: 'status',selectList:statusList,sort:true,templet: Table.templet.select},
                    // {field:'likes',title: __('Likes'),align: 'center',sort:true},
                    // {field:'dislikes',title: __('Dislikes'),align: 'center',sort:true},
                    {field:'flags', title: __('Flags'),align: 'center',sort:true},
                    // {field:'is_comment', title: __('IsComment'),align: 'center',sort:true},
                    // {field:'comments',title: __('Comments'),align: 'center',sort:true},
                    // {field:'is_read',title: __('IsRead'),align: 'center',sort:true},
                    // {field:'price',title: __('Price'),align: 'center',sort:true},
                    {field:'sort',title: __('Sort'),align: 'center',edit:'text',sort:true},
                    {field:'hits',title: __('Hits'),align: 'center',sort:true},
                    {field:'publish_time',title: __('PublishTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    // {field:'create_time',title: __('CreateTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    // {field:'update_time',title: __('UpdateTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    // {field:'delete_time',title: __('DeleteTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    {
                        minWidth: 250,
                        align: "center",
                        title: __("Operat"),
                        init: Table.init,
                        templet: Table.templet.operat,
                        operat: ["edit", "destroy","delete"]
                    },
                ]],
                limits: [10, 15, 20, 25, 50, 100,500],
                limit: 15,
                page: false,
                done: function (res, curr, count) {
                }
            });

            let table = $('#'+Table.init.table_elem);
            Table.api.bindEvent(table);
        },
        add: function () {
            Controller.api.bindevent()
        },
        edit: function () {
            Controller.api.bindevent()
        },
        recycle: function () {
            Table.init = {
                table_elem: 'list',
                tableId: 'list',
                requests: {
                    delete_url:'addons/mocms/backend/cmsTopic/delete',
                    recycle_url:'addons/mocms/backend/cmsTopic/recycle',
                    restore_url:'addons/mocms/backend/cmsTopic/restore',
                    
                },
            };
            Table.render({
                elem: '#' + Table.init.table_elem,
                id: Table.init.tableId,
                url: Fun.url(Table.init.requests.recycle_url),
                init: Table.init,
                toolbar: ['refresh','delete','restore'],
                cols: [[
                    {checkbox: true,},
                    {field: 'id', title: __('ID'), sort:true,},
                    {field:'site_ids', title: __('SiteIds'),align: 'center',sort:true},
                    {field:'pid', title: __('Pid'),align: 'center',sort:true},
                    {field:'member_id', title: __('MemberId'),align: 'center',sort:true},
                    {field:'author', title: __('Author'),align: 'center',sort:true},
                    {field:'title', title: __('Title'),align: 'center',sort:true},
                    {field:'titlestyle', title: __('Titlestyle'),align: 'center',sort:true},
                    {field:'admin_id',search: true,title: __('AdminId'),selectList:adminIdList,sort:true,templet: Table.templet.tags},
                    {field:'seotitle', title: __('Seotitle'),align: 'center',sort:true},
                    {field:'thumb',title: __('Thumb'),sort:true,templet: Table.templet.image},
                    {field:'keywords', title: __('Keywords'),align: 'center',sort:true},
                    {field:'description', title: __('description'),align: 'center',sort:true},
                    {field:'remark', title: __('Remark'),align: 'center',sort:true},
                    {field:'diyname', title: __('Diyname'),align: 'center',sort:true},
                    {field:'tags', title: __('Tags'),align: 'center',sort:true},
                    {field:'status',search: 'select',title: __('Status'),filter: 'status',selectList:statusList,sort:true,templet: Table.templet.select},
                    {field:'likes',title: __('Likes'),align: 'center',sort:true},
                    {field:'dislikes',title: __('Dislikes'),align: 'center',sort:true},
                    {field:'flags', title: __('Flags'),align: 'center',sort:true},
                    {field:'is_comment', title: __('IsComment'),align: 'center',sort:true},
                    {field:'comments',title: __('Comments'),align: 'center',sort:true},
                    {field:'is_read',title: __('IsRead'),align: 'center',sort:true},
                    {field:'price',title: __('Price'),align: 'center',sort:true},
                    {field:'sort',title: __('Sort'),align: 'center',edit:'text',sort:true},
                    {field:'hits',title: __('Hits'),align: 'center',sort:true},
                    {field:'publish_time',title: __('PublishTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    {field:'create_time',title: __('CreateTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    {field:'update_time',title: __('UpdateTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    {field:'delete_time',title: __('DeleteTime'),align: 'center',timeType:'datetime',dateformat:'yyyy-MM-dd HH:mm:ss',searchdateformat:'yyyy-MM-dd HH:mm:ss',search:'time',templet: Table.templet.time,sort:true},
                    {
                        minWidth: 250,
                        align: "center",
                        title: __("Operat"),
                        init: Table.init,
                        templet: Table.templet.operat,
                        operat: ["restore","delete"]
                    },
                ]],
                limits: [10, 15, 20, 25, 50, 100,500],
                limit: 15,
                page: false,
                done: function (res, curr, count) {
                }
            });
            let table = $('#'+Table.init.table_elem);
            Table.api.bindEvent(table);
        },
        api: {
            bindevent: function () {
                Form.api.bindEvent($('form'))
            }
        }
    };
    return Controller;
});
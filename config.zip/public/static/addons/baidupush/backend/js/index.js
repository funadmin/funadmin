define(['jquery','table','form'], function (undefined,Table,Form) {
    let Controller = {
        index: function () {
            Controller.api.bindevent()
        },
        api: {
            bindevent: function () {
                Form.api.bindEvent($('form'), function (res) {
                    Fun.toastr.success(res.msg, setTimeout(function () {
                    }, 0));
                    html = '请求成功:\n';
                    html+=res.data
                    $("textarea[name=result]").val(html);
                    return false;
                }, function (res) {
                    Fun.toastr.error(res.msg);
                    return false;
                })
            }
        }

    };
    return Controller;
});
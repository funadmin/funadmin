define(['jquery','table','form'], function ($,Table,Form) {
    Table.init = {
        table_elem: 'list',
        tableId: 'list',
        requests: {
            index_url: 'addons/curd/backend/index/index',
            delete_url: 'addons/curd/backend/index/delete',
            add_url: 'addons/curd/backend/index/add',
            add_full: {
                type: 'open',
                class: 'layui-btn-sm layui-btn-green',
                url: 'addons/curd/backend/index/add',
                icon: 'layui-icon layui-icon-add',
                text: __('Add'),
                title: __('Add'),
                full: 0,
                height:600,
                extend:"data-btn=''",
            },
        },
    };
    let Controller = {
        index: function () {
            Table.render({
                elem: '#' + Table.init.table_elem,
                id: Table.init.tableId,
                url: Fun.url(Table.init.requests.index_url),
                init: Table.init,
                toolbar: ['refresh','add_full','delete'],
                cols: [[
                    {checkbox: true,},
                    {field: 'id', title: 'ID', width: 80, sort: true},
                    {field: 'admin.username', title: __('Admin'), width: 120,templet: Table.templet.tags},
                    {field: 'post_json', title: __('json'), width: 300},
                    {field: 'curd', title: __('curd'), width: 400,},
                    {field: 'create_time', title: __('createTime'), width: 180,search:'range'},
                    {
                        minwidth: 150,
                        align: 'center',
                        title: __('Operat'),
                        init: Table.init,
                        templet: Table.templet.operat,
                        operat: ['edit_full', 'delete']
                    }
                ]],
                limits: [10, 15, 20, 25, 50, 100],
                limit: 15,
                page: true
            });
            let table = $('#'+Table.init.table_elem);
            Table.api.bindEvent(table);
        },
        add:function () {
            Controller.api.bindevent()
        },
        api: {
            bindevent: function () {
                Form.api.bindEvent($('form'))
                var relTable = [];
                function buildOptions(data,select){
                    var html = [];
                    for (var i = 0; i < data.length; i++) {
                        html.push("<option value='" + data[i] + "'>" + data[i] + "</option>");
                    }
                    select.html(html);
                    layui.form.render();
                };
                layui.form.on('select(table)', function(data){
                    var tableName = data.value;
                    if(!tableName){
                        Fun.toastr.error(__('please choose main table'));
                        return false;
                    }
                    Fun.ajax({url:Table.init.requests.add_url,method:'GET',data:{'tablename':tableName}},function (res){
                        buildOptions(res.data,$('.joinforeignkey'));
                    })
                })
                layui.form.on('select(jointable)', function(data){
                    _that  = $(data.elem);
                    var tableName = data.value;
                    if(!tableName){
                        Fun.toastr.error(__('please choose rel table'));
                        return false;
                    }
                    Fun.ajax({url:Table.init.requests.add_url,method:'GET',data:{'tablename':tableName}},function (res){
                        buildOptions(res.data,_that.parents('tr').find('.joinprimarykey'));
                        buildOptions(res.data,_that.parents('tr').find('.selectfields'));
                        console.log(_that.parents('tr').find('.selectfields'))
                    })
                })
                $('.addRelation').click(function (){
                    let index = relTable.length
                    relTable.push({
                        title: '',
                        content: []
                    })
                    //第三步：渲染模版
                    var data = { //数据
                        "index":index
                    }
                    var tableName = $('select[name="table"]').val();
                    if(!tableName){
                        Fun.toastr.error(__('please choose main table'));
                        return false;
                    }
                    Fun.ajax({url:Table.init.requests.add_url,method:'GET',data:{'tablename':tableName}},function (res){
                        buildOptions(res.data,$('.joinforeignkey'));
                    })
                    var getTpl = tpl.innerHTML
                        ,view = $('#relTab');
                    layui.laytpl(getTpl).render(data, function(html){
                        view.append(html) ;
                    });
                    layui.form.render()
                    // 规格删除按钮事件
                    $(`#relTab-delete-${index}`).click(function (){
                        // 移除元素
                        $(`#relTab-${index}`).remove();
                        // 数组移除
                        relTable.splice(index,1);
                    })
                })
            }
        }

    };
    return Controller;
});
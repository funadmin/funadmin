<?php
return [
        'Level'                                    =>"等级",
        'Leveladd'                                 =>"等级添加",
        'Leveldel'                                 =>"等级删除",
        'Leveledit'                                =>"等级编辑",
        'Leveldesc'                                =>"等级描述",
        'LevelName'                                =>"等级名字",
        'Levelmoney'                               =>"等级金额",
        'Leveldiscount'                            =>"等级折扣 ",
        'Amount'                                   =>"金额 ",
        'Discount'                                 =>"折扣",


    ];
<?php

return [
    'Attach'=>'附件',
    'OriginalName'=>'原名',
    'name'=>'名字',
    'thumb'=>'缩略图',
    'FileType'=>'文件类型',
    'Ext'=>'后缀',
    'url'=>'路径',
    'Path'=>'路径',
    'Size'=>'大小',
    'Driver'=>'驱动',
    'Mime'=>'mime类型',
    'Userid'=>'用户id',
    'Width'=>'宽',
    'Height'=>'高',
    'ALL OR DEFAULT CAN NOT DELETE'=>"默认或全部不能删除",

];
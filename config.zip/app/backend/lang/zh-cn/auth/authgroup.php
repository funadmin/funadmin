<?php

return [
    'access group'=>'分配权限',
    'GroupName'=>'组名',
    'AuthGroupPid'=>'权限组ID'

];
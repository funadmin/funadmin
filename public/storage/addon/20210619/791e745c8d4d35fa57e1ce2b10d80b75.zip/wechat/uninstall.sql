drop table if exists `__PREFIX__addons_wechat_account`;

drop table if exists `__PREFIX__addons_wechat_fans`;

drop table if exists `__PREFIX__addons_wechat_material`;

drop table if exists `__PREFIX__addons_wechat_material_info`;

drop table if exists `__PREFIX__addons_wechat_menu`;

drop table if exists `__PREFIX__addons_wechat_message`;

drop table if exists `__PREFIX__addons_wechat_qrcode`;

drop table if exists `__PREFIX__addons_wechat_reply`;

drop table if exists `__PREFIX__addons_wechat_tags`;

drop table if exists `__PREFIX__addons_wechat_type`;


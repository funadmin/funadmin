<?php

namespace addons\wechat\backend\service;

use app\common\service\AbstractService;
use addons\wechat\backend\model\WechatAccount;
use app\common\traits\Jump;
use EasyWeChat\Factory;
class WechatService extends AbstractService
{
    use Jump;
    protected $wxapp;
    public $config = [];
    public function __construct()
    {
        $this->config = WechatAccount::where('status',1)->cache(3600)->find();
        if($this->config){
            $this->config = $this->config->toArray();
        }
        $this->config['response_type'] = 'array';
    }
    public function wxapp(){
        $this->wxapp = Factory::officialAccount($this->config);
        return $this->wxapp;
    }

}
<?php
/**
 * funadmin
 * ============================================================================
 * 版权所有 2018-2027 funadmin，并保留所有权利。
 * 网站地址: https://www.funadmin.com
 * ----------------------------------------------------------------------------
 * 采用最新Thinkphp6实现
 * ============================================================================
 * Author: yuege
 * Date: 2019/9/4
 */
namespace addons\wechat\backend\controller;

use addons\wechat\backend\model\WechatQrcode;
use app\common\annotation\ControllerAnnotation;
use app\common\annotation\NodeAnnotation;
use app\common\controller\AddonsBackend;
use think\App;
use think\facade\Db;
use think\facade\Request;
use think\facade\View;

/**
 * @ControllerAnnotation('Qrcode')
 * Class Qrcode
 * @package addons\wechat\backend\controller
 */
class Qrcode extends WxBase {

    public function __construct(App $app){
        parent::__construct($app);
        $this->modelClass = new WechatQrcode();
    }
    /**
     * @NodeAnnotation('add')
     * @return \think\response\View
     */
    public function add(){
        if(Request::isPost()){
            $data = Request::param();
            if($data['type']==0){
                $data['expire_seconds'] = $data['expire_seconds']?$data['expire_seconds']:2592000;
                $res = $this->wxapp->qrcode->temporary('foo',$data['expire_seconds']);
            }else{
                $res = $this->wxapp->qrcode->forever('foo');// 或者 $app->qrcode->forever(56);
            }
            $this->showError($res);
            $data['store_id'] = $this->wechatAccount->id;
            $data['addons_wechat_aid'] = $this->store_id;
            $data['ticket'] = $res['ticket'];
            $data['url'] = $res['url'];
            $data['qrcode'] = $url = $this->wechatApp->qrcode->url($res['ticket']);
            if($this->modelClass->save($data)){
                $this->success(lang('add success'));
            }else{
                $this->error(lang('add fail'));
            }
        }
        $view = ['formData'=>''];
        return view('',$view);
    }


}
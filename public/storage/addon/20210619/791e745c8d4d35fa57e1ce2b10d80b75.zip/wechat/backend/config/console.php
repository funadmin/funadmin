<?php
return [
    'commands' => [
        'wechat' => 'addons\wechat\backend\command\Wechat',
    ]
];
<?php
namespace addons\wechat\backend\command;

use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

class Wechat extends Command
{
    protected function configure()
    {
        $this->setName('composer')
            ->addArgument('name', Argument::OPTIONAL, "require or remove")
            ->setDescription('composer');
    }

    protected function execute(Input $input, Output $output)
    {
        $name = trim($input->getArgument('name'));
        $name = $name ?: 'require';
        $composerArr = [
            'overtrue/wechat'=>'composer '.$name.' overtrue/wechat',
        ];
        $composer = \json_decode(file_get_contents($this->app->getRootPath() . 'composer.json'), true);
        try {
            foreach ($composerArr as $k => $v) {
                if (!isset($composer['require'][$k]) && ($name=="require" || $name=='remove')) {
                    exec($v,$output1,$return_var);
                }
            }
        } catch (\Exception $e) {
            $output->error($e->getMessage());
        }
        $output->writeln('ok');
    }
}

?>
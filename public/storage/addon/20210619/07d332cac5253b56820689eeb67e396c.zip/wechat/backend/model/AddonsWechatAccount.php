<?php
declare (strict_types = 1);

namespace addons\wechat\backend\model;
use app\common\model\BaseModel;
use think\Model;

/**
 * @mixin \think\Model
 */
class AddonsWechatAccount extends BaseModel
{
    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }
    
    public function getAppIdList()
    {
        return ;
    }


    public function getMerchantIdList()
    {
        return ;
    }


    public function getOriginIdList()
    {
        return ;
    }


    public function getStatusList()
    {
        return [0=>"enabled",1=>"disabled"];
    }


    public function getTypeList()
    {
        return ['1'=>'普通订阅号','2'=>'认证订阅号','3'=>'普通服务号','4'=>'认证服务号/认证媒体/政府订阅号',];
    }


}

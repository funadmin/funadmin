### 安装完后执行 命令 php think wechat require  安装composer扩展包

### 卸载后执行 命令 php think wechat remove  卸载composer扩展包

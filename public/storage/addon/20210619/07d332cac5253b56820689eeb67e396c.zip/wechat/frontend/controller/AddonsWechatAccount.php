<?php
declare (strict_types = 1);

namespace addons\wechat\frontend\controller;

use think\Request;
use think\App;
use think\facade\View;
use addons\wechat\backend\model\AddonsWechatAccount as AddonsWechatAccountModel;
use app\common\annotation\NodeAnnotation;
use app\common\annotation\ControllerAnnotation;

/**
 * @ControllerAnnotation ('AddonsWechatAccount')
 */
class AddonsWechatAccount extends \app\common\controller\AddonsFrontend
{
    protected $pageSize = 15;
    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->modelClass = new AddonsWechatAccountModel();
{{$assign}}

    }

    
}


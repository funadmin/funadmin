define(['table','form'], function (Table,Form) {
    let Controller = {
        index: function () {
            Table.init = {
                table_elem: 'list',
                tableId: 'list',
                requests:{
                    index_url:'addons/wechat/backend/qrcode/index',
                    add_url:'addons/wechat/backend/qrcode/add',
                    edit_url:'addons/wechat/backend/qrcode/edit',
                    delete_url:'addons/wechat/backend/qrcode/delete',
                    deleteAll_url:'addons/wechat/backend/qrcode/deleteAll',
                }
            }
            Table.render({
                elem: '#' + Table.init.table_elem,
                id: Table.init.tableId,
                url: Fun.url(Table.init.requests.index_url),
                init: Table.init,
                toolbar: ['refresh','add'],
                cols: [[
                    {checkbox: true,},
                    {checkbox: true, },
                    {field: 'id', title: 'ID', width: 80,  sort: true},
                    {field: 'name', title: '二维码名字', width: 120,sort:true},
                    {field: 'type', title: '类型', width: 80,templet:'#type',sort:true},
                    {field: 'qrcode', title: '二维码', width: 120,templet:'#qrcode',sort:true},
                    {field: 'url', title: 'url', width: 120,sort:true},
                    {field: 'ticket', title: 'ticket', width: 120, sort:true},
                    {field: 'expire_seconds', title: '过期时间', width: 120, sort:true},
                    // {field: 'store_id', title: '店铺id', width: 120,sort: true},
                    {field: 'status', title: '接入状态', width: 180, templet:'#status',sort:true},
                    {field: 'create_time', title: '添加时间', width: 180,templet:'#create_time',sort:true},
                    {field: 'update_time', title: '更新时间', width: 180,templet:'#update_time',sort:true},
                    // {field:'delete_time', title: __('delete_time'),align: 'center',sort:'sort'},
                    {
                        minwidth: 250,
                        align: "center",
                        title: __("Operat"),
                        init: Table.init,
                        templet: Table.templet.operat,
                        operat: ["edit",'delete']
                    },
                ]],
                done: function(res){
                },
                //
                limits: [10, 15, 20, 25, 50, 100],
                limit: 15,
                page: true
            });

            let table = $('#'+Table.init.table_elem);
            Table.api.bindEvent(table);
        },
        add: function () {
            Controller.api.bindevent()
        },
        edit: function () {
            Controller.api.bindevent()
        },
        api: {
            bindevent: function () {
                Form.api.bindEvent($('form'))
            }
        }
    };
    return Controller;
});